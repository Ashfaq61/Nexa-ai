from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any
from datetime import datetime

from .config import settings
from .models.schemas import (
    ChatRequest, ChatResponse,
    LiveTokenRequest, LiveTokenResponse,
    ResearchRequest, ToolItem,
    AgentRunRequest, AgentRunResponse,
    UpgradeProposalItem, ProposalApprovalRequest
)
from .tools.mcp_registry import mcp_registry
from .services.live_token_service import LiveTokenService
from .agents.master_agent import master_agent

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    description="Nexus AI Assistant V2.0 Autonomous Backend Engine"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mock in-memory store for reports and memories
reports_store: List[Dict[str, Any]] = [
    {
        "id": "report_latest",
        "date": datetime.utcnow().strftime("%Y-%m-%d"),
        "title": "Daily AI Intelligence Briefing",
        "summary": "Scouted trending agent frameworks (CrewAI, SmolAgents, LangGraph) and tested safely in sandbox.",
        "verified_items_count": 8
    }
]

memories_store: List[Dict[str, Any]] = [
    {"id": "mem_01", "key": "operator_persona", "value": "Direct, safety-focused, prefers technical summaries and voice feedback.", "created_at": datetime.utcnow().isoformat()},
    {"id": "mem_02", "key": "safe_mode", "value": "Strict: Human approval required for all git commits or installs.", "created_at": datetime.utcnow().isoformat()}
]

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "app": settings.APP_NAME,
        "version": settings.VERSION,
        "safe_mode": settings.SAFE_MODE,
        "gemini_model": settings.DEFAULT_GEMINI_MODEL
    }

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(req: ChatRequest):
    # Support English, Urdu, and Roman Urdu understanding
    msg = req.message.strip()
    
    # Nexus Persona Core Response
    if "urdu" in req.language or any(w in msg.lower() for w in ["kya hal hai", "kaise ho", "madad"]):
        reply = f"Salam Operator. Main Project Nexus hoon. Aapka hukam sar ankhon par. Aapne farmaya: '{msg}'. Main system security aur tools monitor kar raha hoon."
    else:
        reply = f"Nexus Neural Core acknowledges: '{msg}'. All sub-agents (Research, Planning, Execution, Memory, Security) are active and operating under strict Safe-Mode."

    return ChatResponse(
        reply=reply,
        session_id=req.session_id or "default",
        agent_trace=["Security: OK", "Planning: OK", "Execution: Synthesized"]
    )

@app.post("/live/token", response_model=LiveTokenResponse)
async def get_live_token(req: LiveTokenRequest):
    return LiveTokenService.generate_ephemeral_token(req.session_id)

@app.post("/research/github", response_model=List[ToolItem])
async def research_github(req: ResearchRequest):
    return await mcp_registry.search_github_ai_agents(query=req.query, limit=req.limit)

@app.post("/research/huggingface", response_model=List[ToolItem])
async def research_huggingface(req: ResearchRequest):
    return await mcp_registry.search_huggingface_models(limit=req.limit)

@app.post("/agent/run", response_model=AgentRunResponse)
async def run_agent(req: AgentRunRequest):
    return await master_agent.execute_task(req)

@app.get("/agent/status")
async def get_agent_status():
    return {
        "nexus_master_agent": "ONLINE",
        "sub_agents": {
            "research_agent": "ACTIVE",
            "planning_agent": "ACTIVE",
            "execution_agent": "ACTIVE",
            "memory_agent": "ACTIVE",
            "improvement_agent": "ACTIVE",
            "security_agent": "ACTIVE (Strict Guardrails)"
        },
        "active_tasks_count": len(master_agent.active_tasks)
    }

@app.post("/reports/daily")
async def generate_daily_report():
    today = datetime.utcnow().strftime("%Y-%m-%d")
    tools = await mcp_registry.search_github_ai_agents(limit=5)
    report = {
        "id": f"report_{int(datetime.utcnow().timestamp())}",
        "date": today,
        "title": f"Nexus Daily Intelligence Briefing ({today})",
        "summary": f"Scouted {len(tools)} trending AI repositories. No unauthorized code modifications allowed.",
        "verified_items_count": len(tools)
    }
    reports_store.insert(0, report)
    return report

@app.get("/reports")
async def get_reports():
    return reports_store

@app.get("/proposals", response_model=List[UpgradeProposalItem])
async def get_proposals():
    return master_agent.get_proposals()

@app.post("/proposals/{proposal_id}/approve")
async def approve_proposal(proposal_id: str, req: ProposalApprovalRequest):
    success = master_agent.approve_proposal(proposal_id)
    if not success:
        raise HTTPException(status_code=404, detail="Proposal not found")
    return {"status": "SUCCESS", "message": f"Proposal {proposal_id} approved by operator.", "is_approved": True}

@app.get("/memory/search")
async def search_memory(query: str = ""):
    if not query:
        return memories_store
    q = query.lower()
    return [m for m in memories_store if q in m["key"].lower() or q in m["value"].lower()]
